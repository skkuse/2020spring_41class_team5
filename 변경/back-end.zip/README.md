## Starting the backend

1. Follow instructions 1-4 in 2020spring_41class_team5 overview
2. CD into the back-end/nutrition folder where manage.py is located
3. Type: python3 manage.py runserver
4. Access the API by calling one of the aviable API URIs (see list bellow)

available superuser: admin@skku.kr, pw: skku2020

## Available API URIs

http://127.0.0.1:8000/users/register/

http://127.0.0.1:8000/users/login/

http://127.0.0.1:8000/deliveries/ # for detail view include tailing <int:pk>
