from django.apps import AppConfig


class MealplansConfig(AppConfig):
    name = 'mealplans'
