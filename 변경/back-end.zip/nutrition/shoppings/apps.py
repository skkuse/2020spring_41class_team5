from django.apps import AppConfig


class ShoppingsConfig(AppConfig):
    name = 'shoppings'
