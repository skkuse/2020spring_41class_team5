from django.apps import AppConfig


class DeliveriesConfig(AppConfig):
    name = 'deliveries'
